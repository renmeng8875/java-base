package cn.hxex.blog.auth.bean;

public class UserInfo {

	private String userId;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
}

