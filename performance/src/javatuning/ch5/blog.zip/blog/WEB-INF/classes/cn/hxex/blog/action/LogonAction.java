package cn.hxex.blog.action;

import cn.hxex.blog.auth.util.AuthorityUtil;
import cn.hxex.blog.dao.DaoFactory;
import cn.hxex.blog.dao.IUserDAO;
import cn.hxex.blog.model.User;

import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
public class LogonAction extends ActionSupport {

	private User user = null;
	
	public String execute() {
		IUserDAO dao = DaoFactory.getUserDAO();
		User u = dao.getUser( user.getName() );
		if( u!=null && u.getPassword().equals( user.getPassword() ) ) {
			
			AuthorityUtil.saveUser( u );
			return SUCCESS;
		}
		addActionError( getText( "logon.failed" ) );
		return INPUT;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
}
