package cn.hxex.blog.action;

import java.sql.Timestamp;

import cn.hxex.blog.dao.DaoFactory;
import cn.hxex.blog.dao.IMessageDAO;
import cn.hxex.blog.model.Message;
import cn.hxex.blog.model.ReplyMessage;

import com.opensymphony.xwork2.ActionSupport;


@SuppressWarnings("serial")
public class ReplySaveAction extends ActionSupport {

	private ReplyMessage reply;
	
	public String execute() {
		IMessageDAO dao = DaoFactory.getMessageDAO();
		Message message = dao.getMessage( reply.getMessage().getId() );
		if( message!=null ) {
			ReplyMessage r = new ReplyMessage();
			r.setUsername( reply.getUsername() );
			r.setTitle( reply.getTitle() );
			r.setContent( reply.getContent() );
			r.setPubdate( new Timestamp( System.currentTimeMillis() ) );
			
			r.setMessage( message );
			message.getReplies().add( r );
		} else {
			addActionMessage( getText( "error.message.not.exist" ) );
		}
		return SUCCESS;
	}

	public ReplyMessage getReply() {
		return reply;
	}

	public void setReply(ReplyMessage reply) {
		this.reply = reply;
	}
}
