package cn.hxex.blog.action;

import cn.hxex.blog.auth.bean.UserInfo;
import cn.hxex.blog.auth.util.AuthorityUtil;
import cn.hxex.blog.dao.DaoFactory;
import cn.hxex.blog.dao.IMessageDAO;
import cn.hxex.blog.model.Message;

import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
public class MessageDeleteAction extends ActionSupport {

	private Message message;
	
	public String execute() {
		UserInfo user = AuthorityUtil.getUser( );
		
		IMessageDAO dao = DaoFactory.getMessageDAO();
		dao.deleteMessage( message.getId(), user.getUserId() );
		return SUCCESS;
	}

	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}	
}
