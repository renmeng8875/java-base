package cn.hxex.blog.action;

import cn.hxex.blog.auth.bean.UserInfo;
import cn.hxex.blog.auth.util.AuthorityUtil;
import cn.hxex.blog.dao.DaoFactory;
import cn.hxex.blog.dao.IMessageDAO;
import cn.hxex.blog.model.ReplyMessage;

import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
public class ReplyDeleteAction extends ActionSupport {

	private ReplyMessage reply;
	
	public String execute() {
		UserInfo user = AuthorityUtil.getUser( );
		
		IMessageDAO dao = DaoFactory.getMessageDAO();
		dao.deleteReplyMessage( reply.getId(), user.getUserId() );

		return SUCCESS;
	}

	public ReplyMessage getReply() {
		return reply;
	}

	public void setReply(ReplyMessage reply) {
		this.reply = reply;
	}
}
