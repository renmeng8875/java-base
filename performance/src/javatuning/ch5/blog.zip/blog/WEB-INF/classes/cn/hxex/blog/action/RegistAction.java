package cn.hxex.blog.action;

import cn.hxex.blog.auth.util.AuthorityUtil;
import cn.hxex.blog.dao.DaoFactory;
import cn.hxex.blog.dao.IUserDAO;
import cn.hxex.blog.model.User;

import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
public class RegistAction extends ActionSupport {

	private User user;
	private String repassword;
	
	public String execute() {
		User u = new User();
		u.setName( user.getName() );
		u.setPassword( user.getPassword() );
		
		IUserDAO dao = (IUserDAO)DaoFactory.getDao( "userDao" );
		dao.saveUser( u );
		
		AuthorityUtil.saveUser( user );
		
		return SUCCESS;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getRepassword() {
		return repassword;
	}

	public void setRepassword(String repassword) {
		this.repassword = repassword;
	}

}
