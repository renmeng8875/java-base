package cn.hxex.blog.exception;

public class BlogAuthorityException extends BlogException {

	/**
	 * Generated serialVersionUID
	 */
	private static final long serialVersionUID = -7193833152544379759L;

	public BlogAuthorityException(String message) {
		super(message);
	}

}
