package cn.hxex.blog.action;

import java.sql.Timestamp;

import cn.hxex.blog.auth.bean.UserInfo;
import cn.hxex.blog.auth.util.AuthorityUtil;
import cn.hxex.blog.dao.DaoFactory;
import cn.hxex.blog.dao.IMessageDAO;
import cn.hxex.blog.dao.IUserDAO;
import cn.hxex.blog.model.Message;
import cn.hxex.blog.model.User;

import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
public class MessageSaveAction extends ActionSupport {

	private Message message;
	
	public String execute() {

		message.setPubdate( new Timestamp( System.currentTimeMillis() ) );
		
		UserInfo ui = AuthorityUtil.getUser( );
		IUserDAO userDao = DaoFactory.getUserDAO();
		User user = userDao.getUserById( ui.getUserId() );
		message.setUser( user );
		
		IMessageDAO dao = DaoFactory.getMessageDAO();
		dao.saveMessage( message );
		
		user.getMessages().add( message );
		
		addActionMessage( getText( "message.save.success" ) );
		
		return SUCCESS;
	}

	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}
	
	
}
