package cn.hxex.blog.exception;

public class BlogDAOException extends BlogException {

	/**
	 * Generated serialVersionUID
	 */
	private static final long serialVersionUID = -2756491085761662854L;

	public BlogDAOException(String message) {
		super(message);
	}

}
