package cn.hxex.blog.action;

import cn.hxex.blog.dao.DaoFactory;
import cn.hxex.blog.dao.IUserDAO;
import cn.hxex.blog.model.User;

import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
public class BlogAction extends ActionSupport {

	private User user;
	
	public String execute() {
		IUserDAO dao = DaoFactory.getUserDAO();
		user = dao.getUser( user.getName() );
		if( user==null ) {
			addActionMessage( getText( "error.user.not.exist" ) );
		}
		return SUCCESS;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
}
