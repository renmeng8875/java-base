package cn.hxex.blog.action;

import cn.hxex.blog.dao.DaoFactory;
import cn.hxex.blog.dao.IMessageDAO;
import cn.hxex.blog.model.Message;

import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
public class ReplyAddAction extends ActionSupport {
	
	private Message message;
	
	public String execute() {
		IMessageDAO dao = (IMessageDAO)DaoFactory.getMessageDAO();
		message = dao.getMessage( message.getId() );
		if( message==null ) {
			addActionMessage( getText( "error.message.not.exist" ) );
		}
		return SUCCESS;
	}

	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}
}
