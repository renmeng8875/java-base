package cn.hxex.blog.exception;

public class BlogException extends RuntimeException {

	/**
	 * Generated serialVersionUID
	 */
	private static final long serialVersionUID = 2414277138903304731L;

	public BlogException( String message )
	{
		super( message );
	}

}
